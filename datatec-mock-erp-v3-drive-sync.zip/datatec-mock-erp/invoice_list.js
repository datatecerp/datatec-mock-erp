/**
 * Logic for Invoice list page.
 */
document.addEventListener('DOMContentLoaded', () => {
  const { getData, formatMoney } = window.datatecStorage;
  const tableBody = document.querySelector('#invoiceTable tbody');
  const newBtn = document.getElementById('newInvoiceBtn');
  // Set year in footer
  const yearSpan = document.getElementById('yearSpan');
  if (yearSpan) yearSpan.textContent = new Date().getFullYear();

  function loadInvoices() {
    const invoices = getData('datatec_invoices', []);
    tableBody.innerHTML = '';
    invoices.forEach((inv) => {
      const tr = document.createElement('tr');
      // Number with link to edit
      const numTd = document.createElement('td');
      const link = document.createElement('a');
      link.href = `invoice_form.html?id=${encodeURIComponent(inv.id)}`;
      link.textContent = inv.number;
      numTd.appendChild(link);
      tr.appendChild(numTd);
      // Date
      const dateTd = document.createElement('td');
      dateTd.textContent = inv.date || '';
      tr.appendChild(dateTd);
      // Due Date
      const dueTd = document.createElement('td');
      dueTd.textContent = inv.dueDate || '';
      tr.appendChild(dueTd);
      // SO Number (clickable link if id present)
      const soTd = document.createElement('td');
      if (inv.soId) {
        const soLink = document.createElement('a');
        soLink.href = `sales_form.html?id=${encodeURIComponent(inv.soId)}`;
        soLink.textContent = inv.soNumber || inv.soId;
        soTd.appendChild(soLink);
      } else {
        soTd.textContent = inv.soNumber || '';
      }
      tr.appendChild(soTd);
      // Customer
      const custTd = document.createElement('td');
      custTd.textContent = inv.customer || '';
      tr.appendChild(custTd);

      // Status (Paid/Unpaid)
      const statusTd = document.createElement('td');
      statusTd.textContent = inv.status || 'Unpaid';
      tr.appendChild(statusTd);
      // Grand total
      const totalTd = document.createElement('td');
      totalTd.style.textAlign = 'right';
      totalTd.textContent = formatMoney(inv.grandTotal || 0);
      tr.appendChild(totalTd);
      // Actions
      const actionTd = document.createElement('td');
      const editBtn = document.createElement('button');
      editBtn.className = 'btn';
      editBtn.textContent = 'View / Edit';
      editBtn.addEventListener('click', () => {
        location.href = `invoice_form.html?id=${encodeURIComponent(inv.id)}`;
      });
      actionTd.appendChild(editBtn);
      tr.appendChild(actionTd);
      tableBody.appendChild(tr);
    });
  }

  newBtn.addEventListener('click', () => {
    location.href = 'invoice_form.html';
  });

  loadInvoices();
});