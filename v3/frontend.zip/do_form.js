/**
 * Logic for Delivery Order form.
 * See datatec_erp/do_form.js for detailed comments. This version is for the standalone
 * datatec-mock-erp application and uses the same storage keys.
 */
document.addEventListener('DOMContentLoaded', () => {
  const {
    getData,
    setData,
    nextNumber,
    getQueryParams,
    saveRecord,
    generateId,
    formatMoney,
  } = window.datatecStorage;
  // DOM references
  const formTitle = document.getElementById('doFormTitle');
  const recordIdField = document.getElementById('doRecordId');
  const numberField = document.getElementById('doNumber');
  const dateField = document.getElementById('doDate');
  const soNumberField = document.getElementById('doSONumber');
  const customerField = document.getElementById('doCustomer');
  const sourceField = document.getElementById('doSource');
  const addressField = document.getElementById('doDeliveryAddress');
  const itemsBody = document.getElementById('doItemsBody');
  const addItemBtn = document.getElementById('doAddItemBtn');
  const saveBtn = document.getElementById('saveDOBtn');
  const backBtn = document.getElementById('backDoBtn');
  const exportBtn = document.getElementById('exportDoBtn');
  // Query params
  const params = getQueryParams();
  let editing = false;
  let deliveryOrder = {};
  if (params.id) {
    const list = getData('datatec_deliveryOrders', []);
    const existing = list.find((doRec) => doRec.id === params.id);
    if (existing) {
      deliveryOrder = JSON.parse(JSON.stringify(existing));
      editing = true;
    }
  } else if (params.soId) {
    const soList = getData('datatec_salesOrders', []);
    const so = soList.find((o) => o.id === params.soId);
    if (so) {
      const doCounter = nextNumber('deliveryOrder');
      // Pad DO number to 4 digits (e.g. 0800)
      const doNum = 'DO' + String(doCounter).padStart(4, '0');
      deliveryOrder = {
        id: generateId(),
        number: doNum,
        date: new Date().toISOString().substring(0, 10),
        soId: so.id,
        soNumber: so.number,
        customer: so.customer,
        source: so.source || '',
        deliveryAddress: so.shipping || '',
        items: so.items.map((it) => ({ sku: it.sku, description: it.description, qty: it.qty, serials: [] })),
      };
    }
  }
  if (!deliveryOrder.id) {
    const doCounter = nextNumber('deliveryOrder');
    const doNum = 'DO' + String(doCounter).padStart(4, '0');
    deliveryOrder = {
      id: generateId(),
      number: doNum,
      date: new Date().toISOString().substring(0, 10),
      soId: '',
      soNumber: '',
      customer: '',
      source: '',
      deliveryAddress: '',
      items: [],
    };
  }
  (function populateCustomers() {
    const list = getData('datatec_customers', []);
    const datalist = document.getElementById('customerList');
    if (datalist) {
      datalist.innerHTML = '';
      list.forEach((c) => {
        const opt = document.createElement('option');
        opt.value = c.name;
        opt.dataset.details = JSON.stringify(c);
        datalist.appendChild(opt);
      });
    }
  })();
  (function populateItems() {
    const items = getData('datatec_items', []);
    let itemList = document.getElementById('itemList');
    if (!itemList) {
      itemList = document.createElement('datalist');
      itemList.id = 'itemList';
      document.body.appendChild(itemList);
    }
    itemList.innerHTML = '';
    items.forEach((it) => {
      const opt = document.createElement('option');
      opt.value = it.sku;
      opt.dataset.details = JSON.stringify(it);
      itemList.appendChild(opt);
    });
  })();
  function fillForm() {
    recordIdField.value = deliveryOrder.id;
    numberField.value = deliveryOrder.number;
    dateField.value = deliveryOrder.date;
    soNumberField.value = deliveryOrder.soNumber || '';
    customerField.value = deliveryOrder.customer || '';
    if (sourceField) sourceField.value = deliveryOrder.source || '';
    addressField.value = deliveryOrder.deliveryAddress || '';
    itemsBody.innerHTML = '';
    if (deliveryOrder.items && deliveryOrder.items.length) {
      deliveryOrder.items.forEach((item) => addItemRow(item));
    } else {
      addItemRow();
    }
    formTitle.textContent = editing ? `Edit Delivery Order ${deliveryOrder.number}` : 'New Delivery Order';
  }
  function addItemRow(item = {}) {
    const tr = document.createElement('tr');
    const skuTd = document.createElement('td');
    const skuInput = document.createElement('input');
    skuInput.type = 'text';
    skuInput.setAttribute('list', 'itemList');
    skuInput.value = item.sku || '';
    skuTd.appendChild(skuInput);
    tr.appendChild(skuTd);
    const descTd = document.createElement('td');
    const descInput = document.createElement('input');
    descInput.type = 'text';
    descInput.value = item.description || '';
    descTd.appendChild(descInput);
    tr.appendChild(descTd);
    const qtyTd = document.createElement('td');
    const qtyInput = document.createElement('input');
    qtyInput.type = 'number';
    qtyInput.min = '0';
    qtyInput.step = '1';
    qtyInput.value = item.qty ?? 0;
    qtyTd.appendChild(qtyInput);
    tr.appendChild(qtyTd);
    const serialTd = document.createElement('td');
    const serialTextarea = document.createElement('textarea');
    serialTextarea.rows = 2;
    serialTextarea.placeholder = 'One serial per line';
    serialTextarea.value = (item.serials || []).join('\n');
    serialTd.appendChild(serialTextarea);
    tr.appendChild(serialTd);
    const removeTd = document.createElement('td');
    const removeBtn = document.createElement('button');
    removeBtn.textContent = '×';
    removeBtn.className = 'btn-danger';
    removeBtn.type = 'button';
    removeBtn.addEventListener('click', () => {
      tr.remove();
    });
    removeTd.appendChild(removeBtn);
    tr.appendChild(removeTd);
    itemsBody.appendChild(tr);
  }
  function gatherData() {
    deliveryOrder.number = numberField.value;
    deliveryOrder.date = dateField.value;
    deliveryOrder.soNumber = soNumberField.value;
    deliveryOrder.customer = customerField.value.trim();
    if (sourceField) deliveryOrder.source = sourceField.value.trim();
    deliveryOrder.deliveryAddress = addressField.value.trim();
    deliveryOrder.items = [];
    const rows = itemsBody.querySelectorAll('tr');
    rows.forEach((row) => {
      const inputs = row.querySelectorAll('input, textarea');
      if (inputs.length >= 4) {
        const sku = inputs[0].value.trim();
        const desc = inputs[1].value.trim();
        const qty = parseFloat(inputs[2].value) || 0;
        const serialText = inputs[3].value;
        const serials = serialText.split(/\n|\r/).map((s) => s.trim()).filter((s) => s);
        if (!sku && !desc && qty === 0 && serials.length === 0) return;
        deliveryOrder.items.push({ sku, description: desc, qty, serials });
      }
    });
  }
  function saveDO() {
    gatherData();
    saveRecord('datatec_deliveryOrders', deliveryOrder);
    if (deliveryOrder.soId) {
      const soList = getData('datatec_salesOrders', []);
      const idx = soList.findIndex((o) => o.id === deliveryOrder.soId);
      if (idx >= 0) {
        const so = soList[idx];
        if (!Array.isArray(so.doNumbers)) so.doNumbers = [];
        if (!so.doNumbers.includes(deliveryOrder.number)) {
          so.doNumbers.push(deliveryOrder.number);
        }
        setData('datatec_salesOrders', soList);
      }
    }
    return deliveryOrder;
  }

  // Build printable HTML for Delivery Order
  function buildPrintableHTML() {
    /*
      Construct a multi-page printable HTML for the Delivery Order. We manually paginate
      the items table so we can compute and inject page numbers like “Page X of Y”.
      We also remove the SO number per user request. Each page repeats the header
      and DO details and ends with a centered page number. Items numbering
      continues across pages.
    */
    const companyAddress = '302.D (East Wing)\nLevel 3 Menara BRDB\n285, Jalan Maarof KUL 59000\nMalaysia';
    const companyName = 'DataTec Hardware Sdn Bhd';
    const tagline = 'Your Trusted Solutions &<br>Hardware Partner';
    const phone = '+60 03-2297 3797';
    const email = 'info@datatec.my';
    const website = 'www.datatec.my';
    // Compute base path for assets so that the logo resolves correctly when printing in a new window
    const basePath = location.href.substring(0, location.href.lastIndexOf('/') + 1);
    /*
      We need to paginate based on the number of rows actually rendered. Each item may have
      multiple serial numbers which can cause a single item to span multiple printed rows. To
      correctly calculate pages and page numbers, expand the items array into an array of
      rows. Each row will represent a single printed row: the first chunk of serials shows
      the quantity, while subsequent chunks leave the quantity blank.
    */
    const items = deliveryOrder.items || [];
    // Helper to chunk serial numbers into a manageable number of lines per row
    function chunkSerials(serialList) {
      if (!serialList || serialList.length === 0) return [''];
      // Ensure serials is an array
      const lines = Array.isArray(serialList) ? serialList : String(serialList).split(/\n|<br>/);
      const chunks = [];
      const maxLinesPerRow = 8;
      for (let i = 0; i < lines.length; i += maxLinesPerRow) {
        chunks.push(lines.slice(i, i + maxLinesPerRow).join('<br>'));
      }
      return chunks;
    }
    // Expand items into rows considering serial chunks
    const expandedRows = [];
    items.forEach((it) => {
      const serialChunks = chunkSerials(it.serials);
      serialChunks.forEach((chunk, idx) => {
        expandedRows.push({
          index: expandedRows.length + 1,
          partNumber: it.sku || '',
          description: it.description || '',
          qty: idx === 0 ? it.qty || 0 : '',
          serials: chunk,
        });
      });
    });
    // Estimate rows per page. Adjust this number to control how many rows appear on each printed page.
    const rowsPerPage = 15;
    const totalPages = Math.max(1, Math.ceil(expandedRows.length / rowsPerPage));
    let html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' + deliveryOrder.number + '</title>';
    html += '<style>';
    html += '@page { margin: 0; }';
    html += 'body { font-family: Arial, sans-serif; margin: 20px; color:#333; }';
    // Overlays to hide default browser header/footer (date/time and URL) when printing
    html += '.print-overlay-top, .print-overlay-bottom { position: fixed; left: 0; width: 100%; height: 10mm; background: #ffffff; z-index: 1; pointer-events: none; }';
    html += '.print-overlay-top { top: 0; }';
    html += '.print-overlay-bottom { bottom: 0; }';
    html += '.header { display:flex; align-items:flex-start; justify-content:space-between; border-bottom:2px solid #073763; padding-bottom:10px; }';
    html += '.header .left { display:flex; align-items:flex-start; }';
    html += '.header img { width:120px; height:auto; margin-right:10px; }';
    html += '.company-info { font-size:12px; line-height:1.2; }';
    html += '.company-info .name { font-weight:bold; font-size:14px; margin-bottom:2px; }';
    html += '.tagline { font-size:18px; font-weight:bold; color:#073763; text-align:right; margin-top:20px; padding-right:40px; }';
    html += 'h2 { text-align:center; color:#073763; margin-top:20px; margin-bottom:10px; }';
    html += 'table { width:100%; border-collapse:collapse; margin-top:15px; font-size:12px; }';
    html += 'table, th, td { border:1px solid #ccc; }';
    html += 'th, td { padding:6px; vertical-align: top; }';
    html += 'th { background-color:#eaf4ff; }';
    html += 'tbody tr:nth-child(even) { background-color:#f7fbff; }';
    html += '.page { page-break-after:always; padding-top: 12mm; padding-bottom: 12mm; }';
    html += '.page:last-child { page-break-after:auto; }';
    html += '.page-number { text-align:center; font-size:10px; margin-top:10px; }';
    html += '.details-table { width:100%; margin-top:10px; font-size:12px; border:0; }';
    html += '.details-table td { border:0; padding:2px; }';
    /*
      Define a simple footer style for the DO PDF.  We use margin-top and a
      top border to visually separate it from the items table.  The font size
      is kept small and the text is left aligned to match the invoice footer
      style.  This footer will appear at the bottom of every page of the
      delivery order printout.
    */
    html += '.do-footer { margin-top:20px; font-size:11px; text-align:left; border-top:1px solid #ccc; padding-top:10px; color:#555; }';
    html += '</style></head><body><div class="print-overlay-top"></div><div class="print-overlay-bottom"></div>';
    for (let p = 0; p < totalPages; p++) {
      html += '<div class="page">';
      html += '<div class="header">';
      html += '<div class="left">';
      html += '<img src="' + basePath + 'assets/company-logo.jpg" alt="logo" />';
      html += '<div class="company-info">';
      html += '<div class="name">' + companyName + '</div>';
      html += '<div>' + companyAddress.replace(/\n/g, '<br>') + '</div>';
      html += '<div>Phone: ' + phone + '</div>';
      html += '<div>Email: ' + email + ' | Web: ' + website + '</div>';
      html += '</div></div>';
      html += '<div class="tagline">' + tagline + '</div>';
      html += '</div>';
      html += '<h2>Delivery Order</h2>';
      html += '<table class="details-table">';
      html += '<tr><td><strong>DO No:</strong> ' + deliveryOrder.number + '</td><td style="text-align:right;"><strong>Date:</strong> ' + deliveryOrder.date + '</td></tr>';
      html += '<tr><td><strong>Source:</strong> ' + (deliveryOrder.source || '') + '</td><td style="text-align:right;"></td></tr>';
      html += '</table>';
      if (p === 0) {
        html += '<p><strong>Customer:</strong> ' + (deliveryOrder.customer || '') + '<br>';
        html += '<strong>Delivery Address:</strong> ' + (deliveryOrder.deliveryAddress || '') + '</p>';
      }
      html += '<table><thead><tr><th>#</th><th>Part Number</th><th>Description</th><th>Qty</th><th>Serial Numbers</th></tr></thead><tbody>';
      const start = p * rowsPerPage;
      const end = Math.min(start + rowsPerPage, expandedRows.length);
      for (let i = start; i < end; i++) {
        const row = expandedRows[i];
        html += '<tr>';
        html += '<td>' + row.index + '</td>';
        html += '<td>' + row.partNumber + '</td>';
        html += '<td>' + row.description + '</td>';
        // Center-align quantity values to improve readability
        html += '<td style="text-align:center;">' + row.qty + '</td>';
        html += '<td>' + row.serials + '</td>';
        html += '</tr>';
      }
      html += '</tbody></table>';
      // Append footer text to each page.  This footer communicates that the
      // goods have been received in good condition and that the delivery order
      // itself serves as proof of delivery.
      html += '<div class="do-footer">';
      html += '<div>Goods received in good condition.</div>';
      html += '<div>This Delivery Order serves as proof of delivery.</div>';
      html += '</div>';
      html += '<div class="page-number">Page ' + (p + 1) + ' of ' + totalPages + '</div>';
      html += '</div>';
    }
    html += '</body></html>';
    return html;
  }

  function exportDoPDF() {
    // Save first to ensure up-to-date data
    saveDO();
    const html = buildPrintableHTML();
    const win = window.open('', '_blank');
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => {
      win.print();
      win.close();
    }, 400);
  }
  addItemBtn.addEventListener('click', () => {
    addItemRow();
  });

  if (exportBtn) {
    exportBtn.addEventListener('click', () => {
      exportDoPDF();
    });
  }
  saveBtn.addEventListener('click', () => {
    saveDO();
    // Remain on the DO page after saving
    alert(`Delivery Order ${deliveryOrder.number} saved.`);
    // No redirection to do_list.html
  });
  backBtn.addEventListener('click', () => {
    if (confirm('Discard changes and return to list?')) {
      location.href = 'do_list.html';
    }
  });
  document.getElementById('yearSpan').textContent = new Date().getFullYear();
  fillForm();
});